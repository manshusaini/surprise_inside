var rollno.=prompt("Enter your roll no.");
var year=prompt("Enter your year");

if(rollno.==1 && year==1){
  alert("login succesfully");
  window.open("index.html");


}

else{
  window.open("fail.html");
}
